<?php
include('DBConnectivity.php');
$query = "SELECT *
FROM recordedaudio
order by date desc
LIMIT 1000 OFFSET 7";

$result = mysqli_query($db, $query);

if(mysqli_num_rows($result) > 0){
    mysqli_begin_transaction($db);
    while ($row = mysqli_fetch_assoc($result)){
        

        $ID = $row['ID'];

        $query = "DELETE FROM recordedaudio WHERE ID = '$ID'";
        $res = mysqli_query($db, $query);

        if($res) {
            unlink($row['audio']);
            unlink($row['image']);
        }else {
            mysqli_rollback($db);
            mysqli_close($db);
            exit();
        }
      
    } 

    mysqli_commit($db);
    mysqli_close($db);
}

mysqli_close($db);
?>